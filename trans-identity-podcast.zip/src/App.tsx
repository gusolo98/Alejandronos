import React from "react";
import TransIdentityPodcast from "./TransIdentityPodcast";

function App() {
  return <TransIdentityPodcast />;
}

export default App;
