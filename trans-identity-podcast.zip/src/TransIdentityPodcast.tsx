
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function TransIdentityPodcast() {
  return (
    <div className="p-6 grid gap-6 max-w-4xl mx-auto">
      <motion.h1 
        className="text-3xl font-bold text-center"
        initial={{ opacity: 0, y: -20 }} 
        animate={{ opacity: 1, y: 0 }}
      >
        Becoming Online: Alejendronos_unos_de_otros
      </motion.h1>

      <motion.p 
        className="text-center text-lg text-gray-600"
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        transition={{ delay: 0.3 }}
      >
        A final project podcast exploring trans, posthuman identity, and digital embodiment.
      </motion.p>

      <div className="flex justify-center mt-4">
        <audio controls>
          <source src="/mnt/data/Becoming Online_ Digital Personas and Identity.wav" type="audio/wav" />
          Your browser does not support the audio element.
        </audio>
      </div>

      <img 
        src="https://upload.wikimedia.org/wikipedia/commons/7/75/El_Salvador_flag_map.svg" 
        alt="Salvadoran Map Flag Icon"
        className="w-48 mx-auto mt-4 rounded-xl shadow-lg"
      />

      {sections.map((section, index) => (
        <motion.div
          key={index}
          className="border rounded-2xl p-4 shadow bg-white"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 * index }}
        >
          <h2 className="text-xl font-semibold mb-2">{section.title}</h2>
          <p className="text-gray-800 whitespace-pre-wrap">{section.content}</p>
        </motion.div>
      ))}

      <div className="text-center mt-8">
        <Button>
          <a href="#" download>
            Download Podcast Script
          </a>
        </Button>
      </div>
    </div>
  );
}

const sections = [
  {
    title: "Intro",
    content: `Hi, welcome to this episode of Becoming Online.
This is my final project exploring trans and posthuman identities through the creation of a digital persona.
I started with a simple question:
If we can be anything online… does that make identity meaningless? Or more meaningful?`
  },
  {
    title: "Building a Persona",
    content: `Let me introduce you to Alejendronos_unos_de_otros — a Salvadoran demi-god.
He’s always existed, watching from the sidelines.
But now, thanks to modern technology, he can finally speak.
He’s an average brown young man.
Jesus-like, but softer. Wise, emotional, vocal, and present.
He shows up when the world is in crisis.`
  },
  {
    title: "Why This Persona Felt Right",
    content: `This character had to reflect something real in me.
I couldn’t make a version of myself that felt detached or unserious.
Everything I posted came from my own beliefs.
I was transparent: I said in my bio that this was an art project.
Even then, I paid close attention when I interacted with pages that felt authentic.`
  },
  {
    title: "Playing vs. Catfishing",
    content: `Where’s the line between playful role-playing and unethical catfishing?
Honestly, ethics are subjective.
But I think character matters most.
When you dull or hide your core values, that starts to feel dishonest.
Even if no one gets hurt, something’s off.`
  },
  {
    title: "What Trans Perspectives Showed Me",
    content: `Trans identities teach us that we’ve always had more options than we were told.
They remind us that construction and change are possible.
This project intersected with those ideas.
I wasn’t imitating transness —
But I was emphasizing a part of myself that I often keep quiet.`
  },
  {
    title: "The Constraints of Power",
    content: `I want to be vocal and radical.
But I have to think about my job, my family, my safety.
Even this demi-god persona couldn’t go all the way.
His limitations mirrored my own.`
  },
  {
    title: "Identity and Technology",
    content: `If we can endlessly customize ourselves online,
What does that mean for human identity?
Posthuman and cyborg theory say identity isn’t fixed —
We are constantly becoming.
But even in digital space, power structures still exist.`
  },
  {
    title: "What I Learned",
    content: `This project didn’t make me feel fake.
It made me feel more seen.
Trying on this identity made me more grounded in my own.
It didn’t dilute who I am — it made me think harder about it.`
  },
  {
    title: "Outro",
    content: `Thanks for listening.
This was my experiment — not just in building a persona,
But in exploring what identity means when you’re allowed to imagine it freely.`
  }
];
