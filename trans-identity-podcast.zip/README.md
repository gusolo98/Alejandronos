# Trans Identity Podcast

This is a React-based presentation for a final project titled *Becoming Online: Alejendronos_unos_de_otros*. It explores trans and posthuman identity through digital performance.

## How to View

1. Clone or upload this repo to GitHub.
2. Deploy directly using [Vercel](https://vercel.com/).

Enjoy the presentation!
